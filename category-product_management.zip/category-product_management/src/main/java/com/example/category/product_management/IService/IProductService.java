package com.example.category.product_management.IService;

import java.util.List;

import java.util.Optional;

import com.example.category.product_management.models.Products;


public interface IProductService 
{
	
	public Products addProduct(Products product);
	
	public List<Products> getAllProduct();
	
	public Optional<Products> getProductById(int id);
	
	public Products updateProduct(int id,Products product);
	
	public void deleteProduct(int id);
	
	

}
