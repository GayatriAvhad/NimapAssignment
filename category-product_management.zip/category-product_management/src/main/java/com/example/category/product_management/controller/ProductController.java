package com.example.category.product_management.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.category.product_management.models.Products;
import com.example.category.product_management.services.ProductService;

@RestController
@RequestMapping("/api")
public class ProductController 
{
	@Autowired
	private ProductService productService;
	
	//add Product
	@PostMapping("/product")
	public Products addProductDetails(@RequestBody Products product) 
	{
		return productService.addProduct(product);
	}
	
	//get all product
	@GetMapping("/getallproduct")
	public List<Products> getAllProducts()
	{
		return productService.getAllProduct();
	}
	
	//get product by id
	@GetMapping("/product/{id}")
	public ResponseEntity<Products> getProductById(@PathVariable int id)
	{
		Products pro=productService.getProductById(id).orElse(null);
		
		if(pro!=null) {
			
			return ResponseEntity.ok().body(pro);
		}
		else 
		{
			return ResponseEntity.notFound().build();
		}
	}
	
	//update product by id
	@PutMapping("/product/{id}")
	public ResponseEntity<Products> updateProduct(@PathVariable int id,@RequestBody Products product)
	{
		Products updateProduct=productService.updateProduct(id, product);
		
		if(updateProduct!=null)
		{
			return ResponseEntity.ok().body(updateProduct);
			
		}
		else 
		{
			return ResponseEntity.notFound().build();
		}
	}
	
	//delete product by id
	@DeleteMapping("/product/{id}")
	public ResponseEntity<Void> deleteProduct(@PathVariable int id)
	{
		productService.deleteProduct(id);
		
		return ResponseEntity.noContent().build();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
