package com.example.category.product_management.IService;

import java.util.List;

import java.util.Optional;

import com.example.category.product_management.models.Categories;


public interface ICategoryService {

	public Categories createCategory(Categories category);
	
	public List<Categories> getAllCategory();

	public Optional<Categories> getCategoryById(int id);
	
	public Categories updateCategoryById(int id,Categories category);
	
	public void deleteCategoryById(int id);
	
	
}
