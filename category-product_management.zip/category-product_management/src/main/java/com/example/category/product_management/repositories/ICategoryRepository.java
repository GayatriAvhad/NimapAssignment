package com.example.category.product_management.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.category.product_management.models.Categories;



public interface ICategoryRepository extends JpaRepository<Categories,Integer>{

}
