package com.example.category.product_management.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.category.product_management.models.Categories;

import com.example.category.product_management.services.CategoryService;

@RestController
@RequestMapping("/api")
public class CategoryController {
	
	@Autowired
	private CategoryService category_service;
	
	@PostMapping("/category")
	public Categories addCategoryDetails(@RequestBody Categories category)// @RequestBody we data from this
	{
	
		System.out.println(category);
		return category_service.createCategory(category);
		
	}
	
	@GetMapping("/getallcategory")
	public List<Categories> getAllCategoryDetails(){
		System.out.println("inisde get cat");
		System.out.println(category_service.getAllCategory());
		return category_service.getAllCategory();
	}
	
	@GetMapping("/category/{id}")
	public ResponseEntity<Categories> getCategoryById(@PathVariable int id)
	{
		Categories cat =category_service.getCategoryById(id).orElse(null);
		if(cat!=null) 
		{
			return ResponseEntity.ok().body(cat);
		}
		else {
			return ResponseEntity.notFound().build();
		}		
		
	}
	
	@PutMapping("/updatecategory/{id}")
	public ResponseEntity<Categories> updateCategory(@PathVariable int id,@RequestBody Categories cate)
	{
		
		Categories updateCategory =category_service.updateCategoryById(id, cate);
		
		if(updateCategory!=null) 
		{
			return ResponseEntity.ok().body(updateCategory);
		}
		else {
			return ResponseEntity.notFound().build();
		}		
	}
	
	@DeleteMapping("/category/{id}")
	public ResponseEntity<Void> deleteById(@PathVariable int id)
	{
		category_service.deleteCategoryById(id);
		return ResponseEntity.notFound().build();		
	}

}
