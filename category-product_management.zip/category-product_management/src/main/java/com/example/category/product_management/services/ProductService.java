package com.example.category.product_management.services;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.category.product_management.IService.IProductService;
import com.example.category.product_management.models.Products;
import com.example.category.product_management.repositories.IProductRepository;


@Service
public class ProductService implements IProductService   
{

	@Autowired
	private IProductRepository product_repository;
	
	@Override
	public Products addProduct(Products product) {
		// TODO Auto-generated method stub
		return product_repository.save(product);
	}

	@Override
	public List<Products> getAllProduct() {
		// TODO Auto-generated method stub
		return product_repository.findAll();
	}

	@Override
	public Optional<Products> getProductById(int id) {
		// TODO Auto-generated method stub
		return product_repository.findById(id);
	}

	@Override
	public Products updateProduct(int id, Products newproduct) {
		// TODO Auto-generated method stub
		
		Products product=product_repository.findById(id).orElse(null);
		
		if(newproduct!=null) {
			return  product_repository.save(newproduct);
		}
		else {
			throw new RuntimeException("user not found with id :"+id);
		}
	}

	@Override
	public void deleteProduct(int id) {
		// TODO Auto-generated method stub
		product_repository.deleteById(id);
	}

}
