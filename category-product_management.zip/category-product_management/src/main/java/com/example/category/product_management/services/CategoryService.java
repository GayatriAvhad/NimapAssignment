package com.example.category.product_management.services;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.category.product_management.IService.ICategoryService;
import com.example.category.product_management.models.Categories;

import com.example.category.product_management.repositories.ICategoryRepository;

@Service
public class CategoryService implements ICategoryService
{

	@Autowired
	private ICategoryRepository category_repository;
	
	
	@Override
	public Categories createCategory(Categories category) {
		// TODO Auto-generated method stub
		System.out.println(category);
		return category_repository.save(category);
	}


	@Override
	public List<Categories> getAllCategory() {
		// TODO Auto-generated method stub
		return category_repository.findAll();
	}


	@Override
	public Optional<Categories> getCategoryById(int id) {
		// TODO Auto-generated method stub
		return category_repository.findById(id);
			
	}


	@Override
	public Categories updateCategoryById(int id, Categories newCategory) {
		// TODO Auto-generated method stub
		Categories cat=category_repository.findById(id).orElse(null);
		
		if(cat!=null) {
			return category_repository.save(newCategory);
		}
		else {
			throw new RuntimeException("user not found with id :"+id);
		}
		
		
	}


	@Override
	public void deleteCategoryById(int id) {
		// TODO Auto-generated method stub
		 category_repository.deleteById(id);;
	}


	


	

}
