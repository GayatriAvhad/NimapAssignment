
#create database
create database category_product_db;

#use this database
use category_product_db;

drop table categories;

create database categoryproductdb;
use categoryproductdb;

create database apidb;

drop database category_product_db;

